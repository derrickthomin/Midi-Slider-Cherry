import storage
import microcontroller

# Overclock the CPU 
microcontroller.cpu.frequency = 270_000_000

# Keep filesystem writable by USB/computer (readonly=True means CircuitPython can't write)
storage.remount("/", readonly=True)
m = storage.getmount("/")
m.label = "LUMAFADER"
storage.enable_usb_drive()